Schematic Symbol for c2mos latch
