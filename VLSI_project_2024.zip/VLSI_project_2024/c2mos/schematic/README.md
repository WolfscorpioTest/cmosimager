schematic for c2mos latch
